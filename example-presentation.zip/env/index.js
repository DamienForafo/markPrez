console.log("Doing stuff...");
setTimeout(() => {
    console.log("Hello, World!");
    process.exit(0);
}, 1000);
